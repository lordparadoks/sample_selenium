from tests.page.abstract_page import AbstractPage

class PostEditTeacherProfilePage(AbstractPage):
    def __init__(self, driver):
        super(PostEditTeacherProfilePage, self).__init__(driver)