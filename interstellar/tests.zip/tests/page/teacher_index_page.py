from tests.page.edit_teacher_profile_page import EditTeacherProfilePage
from selenium.webdriver.common.action_chains import ActionChains
from tests.page.abstract_page import AbstractPage

class TeacherIndexPage(AbstractPage):

    def __init__(self, driver):
        super(TeacherIndexPage, self).__init__(driver)

    def open_teacher_profile_page(self):
        dropdown_hover = self.driver.find_element_by_css_selector('.profile-dropdown > a.current')
        hover = ActionChains(self.driver).move_to_element(dropdown_hover)
        hover.perform()
        self.driver.find_element_by_css_selector('.profile-dropdown li:nth-child(1) a.hint').click()
        return EditTeacherProfilePage(self.driver)